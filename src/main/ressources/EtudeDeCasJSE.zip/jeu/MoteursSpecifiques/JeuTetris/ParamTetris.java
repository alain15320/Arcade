package MoteursSpecifiques.JeuTetris;

public class ParamTetris {
  public static final int FREQUENCE_MAJ = 5;    
  public static final int TAILLE_CELLULE = 15;
  public static final int LIGNES = 30; 
  public static final int COLONNES = 20;
  public static final int TETROMINO=1;
  public static final String FICHIER_BLANC = "blank.png";
}