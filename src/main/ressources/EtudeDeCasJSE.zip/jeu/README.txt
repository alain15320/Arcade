Sous Windows avec java correctement install�.
1) D�compresser le r�pertoire jeu quelque part.
2) Compiler avec preparer.bat.
3) Lancer les jeux avec le .bat correspondant.