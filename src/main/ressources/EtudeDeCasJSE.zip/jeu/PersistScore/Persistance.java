package PersistScore;

public enum Persistance {FICHIER_TEXTE, SERIALISATION};