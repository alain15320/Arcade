package MoteurGenerique;

public abstract class FabriqueObjets {
  public abstract ObjetJeu creerObjet(int type);
}